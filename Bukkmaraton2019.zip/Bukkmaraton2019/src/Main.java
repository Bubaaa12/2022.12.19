import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

        //BUBLA LEVENTE

        public static void main(String[] args) {
            // 3
            Versenytav[] versenytavak = new Versenytav[1000];
            try {
                File file = new File("src/bukkm2019.txt");
                Scanner sc = new Scanner(file);
                sc.nextLine();
                int i = 0;
                while (sc.hasNextLine()) {
                    String line = sc.nextLine();
                    String[] parts = line.split(";");
                    String rajtszam = parts[0];
                    String kategoria = parts[1];
                    String nev = parts[2];
                    String egyesulet = parts[3];
                    String ido = parts[4];
                    versenytavak[i] = new Versenytav(rajtszam, kategoria, nev, egyesulet, ido);
                    i++;
                }
                sc.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 4.
            System.out.println(((691- versenytavak.length) / 691)*100 +"% aránya a nem indultaknak ....");
            // 5.
            int rovidtaVNok = 0;
            for (int i = 0; i < versenytavak.length; i++) {
                if (versenytavak[i] == null) {
                    break;
                }
                if (versenytavak[i].getRajtszam().charAt(0) == 'R'  && versenytavak[i].getKategoria().charAt(versenytavak[i].getKategoria().length()) == 'N' ) {
                    rovidtaVNok++;
                }
            }
            System.out.println("A rövidtávú versenyen elindult női versenyzők száma: " + rovidtaVNok);
            // 6.
            boolean voltTobbMintHatOraVersenyzo = false;
            for (int i = 0; i < versenytavak.length; i++) {
                if (versenytavak[i] == null) {
                    break;
                }
                String[] parts = versenytavak[i].getIdo().split(":");
                int ora = Integer.parseInt(parts[0]);
                if (ora > 6) {
                    voltTobbMintHatOraVersenyzo = true;
                    break;
                }
            }
            if (voltTobbMintHatOraVersenyzo) {
                System.out.println("Volt ilyen versenyző");
            } else {
                System.out.println("Nem volt ilyen versenyző");
            }

            // 7.
            String  rovidtaVFFGyoztesRajtszam = "";
            String rovidtaVFFGyoztesIdo = "";
            String rovidtaVFFGyoztesNev = "";
            String rovidtaVFFGyoztesEgyesulet = "";
            for (int i = 0; i < versenytavak.length; i++) {
                if (versenytavak[i] == null) {
                    break;
                }
                if (versenytavak[i].getRajtszam().charAt(0) == 'R' &&  versenytavak[i].getKategoria().equals("ff")) {
                    if (rovidtaVFFGyoztesRajtszam == "") {
                        rovidtaVFFGyoztesRajtszam = versenytavak[i].getRajtszam();
                        rovidtaVFFGyoztesIdo = versenytavak[i].getIdo();
                        rovidtaVFFGyoztesNev = versenytavak[i].getNev();
                        rovidtaVFFGyoztesEgyesulet = versenytavak[i].getEgyesulet();
                    }
                    else if (versenytavak[i].getIdo().compareTo(rovidtaVFFGyoztesIdo) < 0) {
                        rovidtaVFFGyoztesRajtszam = versenytavak[i].getRajtszam();
                        rovidtaVFFGyoztesIdo = versenytavak[i].getIdo();
                        rovidtaVFFGyoztesNev = versenytavak[i].getNev();
                        rovidtaVFFGyoztesEgyesulet = versenytavak[i].getEgyesulet();
                    }
                }
            }
            System.out.println("A rövidtávú verseny felnőtt férfi kategóriájának győztese: ");
            System.out.println("Rajtszám: " + rovidtaVFFGyoztesRajtszam);
            System.out.println("Név: " + rovidtaVFFGyoztesNev);
            System.out.println("Egyesület: " + rovidtaVFFGyoztesEgyesulet);
            System.out.println("Idő: " + rovidtaVFFGyoztesIdo);

            // 8.
            int ffCelbaErkezoFeroFiVersenyzokSzama = 0;
            for (int i = 0; i < versenytavak.length; i++) {
                if (versenytavak[i] == null) {
                    break;
                }
                if (versenytavak[i].getKategoria().equals("ff") && versenytavak[i].getRajtszam().charAt(0) == 'R') {
                    ffCelbaErkezoFeroFiVersenyzokSzama++;
                }
            }
            System.out.println("A felnőtt férfi kategóriában célba érkező versenyzők száma: " + ffCelbaErkezoFeroFiVersenyzokSzama);
        }
}
