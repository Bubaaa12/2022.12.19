// 2. 
class Versenytav {
    private String rajtszam;
    private String kategoria;
    private String nev;
    private String egyesulet;
    private String ido;

    public Versenytav(String rajtszam, String kategoria, String nev, String egyesulet, String ido) {
        this.rajtszam = rajtszam;
        this.kategoria = kategoria;
        this.nev = nev;
        this.egyesulet = egyesulet;
        this.ido = ido;
    }

    public String getRajtszam() {
        return rajtszam;
    }

    public void setRajtszam(String rajtszam) {
        this.rajtszam = rajtszam;
    }

    public String getKategoria() {
        return kategoria;
    }

    public void setKategoria(String kategoria) {
        this.kategoria = kategoria;
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public String getEgyesulet() {
        return egyesulet;
    }

    public void setEgyesulet(String egyesulet) {
        this.egyesulet = egyesulet;
    }

    public String getIdo() {
        return ido;
    }

    public void setIdo(String ido) {
        this.ido = ido;
    }
}